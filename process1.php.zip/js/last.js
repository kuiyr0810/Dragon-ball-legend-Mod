// last.js
/*
document.addEventListener("contextmenu", function(event){
    event.preventDefault();
    alert("\u53F3\u952E\u529F\u80FD\u5DF2\u7981\u7528\uFF01!");
});
*/